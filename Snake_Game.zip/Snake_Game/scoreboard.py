
from turtle import Turtle
ALIGMENT = "center"
FONT = ("Arial", 24, "normal")


class Score(Turtle):
    def __init__(self):
        super(Score,self).__init__()
        self.score = 0
        self.color("white")
        self.penup()
        self.goto(0,270)
        self.hideturtle()
        self.update_scoreboard()


    def update_scoreboard(self):
        self.clear()
        self.write(arg="score: ", align="right", font=FONT)
        self.write(arg= self.score, align=ALIGMENT, font=FONT)

    def increase_score(self):
        self.score += 1
        self.update_scoreboard()


class Score2(Turtle):
    def __init__(self):
        super(Score2, self).__init__()
        try:
          with open("my.file.txt") as file:
           data = file.read().strip()
           self.high_score = int(data) if data else 0
        except(ValueError):
         self.high_score = 0
        self.color("white")
        self.penup()
        self.goto(270, 270)
        self.hideturtle()
        self.update_scoreboard2()

    def update_scoreboard2(self):
        self.clear()
        self.write(arg="High score: ", align="right", font=FONT)
        self.write(arg=self.high_score, align=ALIGMENT, font=FONT)

    def reset(self):
        if self.score > self.high_score:
            self.high_score =self.score
            with open("my.file.txt",mode="w") as file:
                file.write(str(self.high_score))


        self.score = 0
        self.update_scoreboard2()

    def increase_score2(self):
        self.high_score += 1
        self.update_scoreboard2()


